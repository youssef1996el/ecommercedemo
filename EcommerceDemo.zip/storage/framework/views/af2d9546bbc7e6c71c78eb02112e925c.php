


<!doctype html>
<html lang="en" >
<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	    <!-- CSRF Token -->
    <meta name="csrf-token" content="a4auVSpLJj2AIopqICdW3my4u9s9wcxBwclNsx6H">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<title>Home</title>
		<meta name="keywords" content="Lorem Ipsum un testo segnaposto utilizzato nel settore della tipografia e della stampa." />
	<meta name="description" content="Lorem Ipsum un testo segnaposto utilizzato nel settore della tipografia e della stampa." />
	<meta property="og:title" content="Lorem Ipsum un testo segnaposto utilizzato nel settore della tipografia e della stampa." />
	<meta property="og:site_name" content="bShop" />
	<meta property="og:description" content="Lorem Ipsum un testo segnaposto utilizzato nel settore della tipografia e della stampa." />
	<meta property="og:type" content="website" />
	<meta property="og:url" content="https://bshopen.themeposh.net" />
	<meta property="og:image" content="https://bshopen.themeposh.net/public/media/06082021062332-200x200-slider-1.jpg" />
	<meta property="og:image:width" content="600" />
	<meta property="og:image:height" content="315" />
		<meta name="twitter:card" content="summary_large_image">
		<meta name="twitter:url" content="https://bshopen.themeposh.net">
	<meta name="twitter:title" content="Lorem Ipsum un testo segnaposto utilizzato nel settore della tipografia e della stampa.">
	<meta name="twitter:description" content="Lorem Ipsum un testo segnaposto utilizzato nel settore della tipografia e della stampa.">
	<meta name="twitter:image" content="https://bshopen.themeposh.net/public/media/06082021062332-200x200-slider-1.jpg">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

		<!--favicon-->
	<link rel="shortcut icon" href="https://bshopen.themeposh.net/public/media/06082021041057-favicon.ico" type="image/x-icon">
	<link rel="icon" href="https://bshopen.themeposh.net/public/media/06082021041057-favicon.ico" type="image/x-icon">
	<!-- css -->
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
		<link href="https://bshopen.themeposh.net/public/frontend/css/bootstrap.min.css" rel="stylesheet">
		<style type="text/css">
	:root {
	  --theme-color: #c62f2f;
	  --menu-background-color: #2d3748;
	}
	</style>
	<link href="https://bshopen.themeposh.net/public/frontend/css/bootstrap-icons.css" rel="stylesheet">
	<link href="https://bshopen.themeposh.net/public/frontend/css/owl.carousel.min.css" rel="stylesheet">
	<link href="https://bshopen.themeposh.net/public/frontend/css/jquery.gritter.min.css" rel="stylesheet">
	<link href="https://bshopen.themeposh.net/public/frontend/css/style.css" rel="stylesheet">
	<link href="https://bshopen.themeposh.net/public/frontend/css/responsive.css" rel="stylesheet">
		</head>
<body >
		<!--loader-->
	<div class="tw-loader">
		<div class="tw-ellipsis">
			<div></div><div></div><div></div><div></div>
		</div>
	</div>
	<!--/loader/-->
	<!-- scrollToTop -->
	<a href="#top" class="scroll-to-top">
		<i class="fa-solid fa-arrow-up"></i>
	</a>
	<!-- /scrollToTop -->

	<!--Top Header-->
	<div class="top-header">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
                    <ul class="top-contact">
                        
                    </ul>
				</div>
				<div class="col-lg-6">
					<ul class="top-list">
						
																								<li><a href="<?php echo e(url('register')); ?>"><i class="bi bi-person-plus"></i>Register</a></li>
												<li><a href="<?php echo e(url('login')); ?>"><i class="bi bi-person"></i>Sign in</a></li>

												<li>
							<div class="btn-group language-menu">
					<a href="javascript:void(0);" class="dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
						<i class="bi bi-translate"></i>English
					</a>
					<ul class="dropdown-menu dropdown-menu-end">
						<li><a class="dropdown-item" href="#">English</a></li>
					</ul>
				</div>						</li>
											</ul>
				</div>
			</div>
		</div>
	</div><!--/Top Header/-->

	<!--Header-->
	<header id="sticky-header" class="header">
		<div class="header-area">
			<div class="container">
				<div class="navbar-content">
					<ul class="head-round-icon">
						<li class="off-canvas-btn"><a href="javascript:void(0);"><i class="fa-solid fa-list"></i></a></li>
						<li class="off-canvas-btn"><a href="javascript:void(0);"><i class="fa-solid fa-magnifying-glass"></i></a></li>
					</ul>
					<div class="navbar-logo">
						<a href="<?php echo e(url('/')); ?>">
							<img src="https://static.vecteezy.com/ti/vecteur-libre/t2/2427590-logo-boutique-avec-un-sac-shopping-sur-fond-blanc-gratuit-vectoriel.jpg" alt="logo">
						</a>
					</div>
					<div class="header-search">
						<form method="GET" action="#">
							<input name="search" type="text" class="form-control" placeholder="Search for Products" required/>
							<button type="submit" class="btn btn-search"><i class="fa-solid fa-magnifying-glass"></i>Search</button>
						</form>
					</div>
					<ul class="head-round-icon">
						<li>
							<a href="<?php echo e(url('Favoirte')); ?>">
								<i class="fa-solid fa-heart"></i>
								<span class="cart_count count_wishlist">0</span>
							</a>
						</li>
						<li>
							<a href="javascript:void(0);" class="sidebar_show_hide">
								<i class="fa-solid fa-cart-shopping"></i>
								<span class="cart_count total_qty">0</span>
							</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</header><!--/Header/-->

	<!--Menu-->
	<div class="header-menu">
		<div class="container">
			<div class="row">
				<div class="col-lg-3">
					<div class="categories_wrap">
						<div class="banner-cate-heading">
							<i class="fa-solid fa-list"></i>Top Categories
						</div>
						<div class="nav_cat_content">
							<ul class="banner-category-list">
                                <?php $__currentLoopData = $Category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(url('productByCategory/' . $item->id)); ?>"><?php echo e($item->name); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
						</div>
					</div>
				</div>

			</div>
		</div>
	</div><!--/Menu/-->

	<!-- off-canvas menu start -->
	<aside class="mobile-menu-wrapper">
		<div class="off-canvas-overlay"></div>
		<div class="offcanvas-body">
			<div class="offcanvas-top">
				<div class="offcanvas-btn-close">
					<i class="bi bi-x-lg"></i>
				</div>
			</div>
			<div class="search-for-mobile">
				<form method="GET" action="#">
					<input name="search" type="text" class="form-control" placeholder="Search for Products" required />
					<button type="submit" class="btn theme-btn"><i class="fa-solid fa-magnifying-glass"></i>Search</button>
				</form>
			</div>
			<div class="mobile-navigation">
				<nav>
					<ul class="mobile-menu">
						<li class="has-children-menu"><a href="#">Top Categories</a>
							<ul class="dropdown">
								<?php $__currentLoopData = $Category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(url('productByCategory/'.$item->id)); ?>"><?php echo e($item->name); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
						</li>


				</nav>
			</div>
		</div>
	</aside>
	<!-- /off-canvas menu start -->
			<!-- Home Slider -->
	<div class="slider-section">
		<div class="container">
			<div class="row">
				<div class="col-lg-9 offset-lg-3">
					<div class="home-slider owl-carousel">
                        <?php $__currentLoopData = $Advertisement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="slider-item">
                                <a href="#">
                                    <img src="<?php echo e(asset('storage/images/' . $item->image)); ?>" alt="" />
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- /Home Slider/ -->

	<!-- Banner Item -->
	<div class="section">
		<div class="container">
			<div class="row">
				<div class="col-sm-12 col-md-12 col-lg-4 col-xl-4 col-xxl-4">
										<div class="banner-item mb25">
						<div class="banner-item-img">
							<img src="https://bshopen.themeposh.net/public/media/06082021083010-category-1.jpg" alt="New"/>
						</div>
						<div class="banner-item-info">
							<h2>New</h2>
							<h4>Collection</h4>
							
						</div>
					</div>
															<div class="banner-item mb25">
						<div class="banner-item-img">
							<img src="https://bshopen.themeposh.net/public/media/06082021083106-category-2.jpg" alt="Hot"/>
						</div>
						<div class="banner-item-info">
							<h2>Hot</h2>
							<h4>Collection</h4>
							
						</div>
					</div>
									</div>
								<div class="col-sm-12 col-md-12 col-lg-4 col-xl-4 col-xxl-4">
					<div class="banner-item mb25">
						<div class="banner-item-img">
							<img src="https://bshopen.themeposh.net/public/media/06082021083154-bag.jpg" alt="10% Offer"/>
						</div>
						<div class="banner-item-info">
							<h2>10% Offer</h2>
							<h4>No Selected Models</h4>
							
						</div>
					</div>
				</div>
								<div class="col-sm-12 col-md-12 col-lg-4 col-xl-4 col-xxl-4">
										<div class="banner-item mb25">
						<div class="banner-item-img">
							<img src="https://bshopen.themeposh.net/public/media/06082021083231-category-4.jpg" alt="New"/>
						</div>
						<div class="banner-item-info">
							<h2>New</h2>
							<h4>Arrivals</h4>
							
						</div>
					</div>
															<div class="banner-item mb25">
						<div class="banner-item-img">
							<img src="https://bshopen.themeposh.net/public/media/06082021083332-category-5.jpg" alt="Hot"/>
						</div>
						<div class="banner-item-info">
							<h2>Hot</h2>
							<h4>Offer</h4>
							
						</div>
					</div>
									</div>
			</div>
		</div>
	</div>
	<!-- /Banner Item/ -->

	<!--Brand Slider-->
	<div class="section">
		<div class="container">
			<div class="row">
				<div class="section-heading">
					<h3 class="title">Shop by Brands</h3>
				</div>
			</div>
			<div class="row owl-carousel caro-common brands-carousel">
                <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-12">
                        <div class="brand-card">
                            <a href="#">
                                <img src="<?php echo e(asset('storage/images/' . $item->patch)); ?>" alt="CA Brand"/>
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</div>
	<!--/Brand Slider/-->

	<!-- New Arrivals Section -->
	<div class="section">
		<div class="container">
			<div class="row">
				<div class="section-heading">
					<h3 class="title">New Arrivals</h3>

				</div>
			</div>

			<div class="row owl-carousel caro-common category-carousel">
                <?php $__currentLoopData = $productNew; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-12">
                        <div class="item-card mb30">
                            <div class="item-image">
                                <ul class="labels-list">
                                    <li><span class="tplabel" style="background:#222222;">NEW</span></li>
                                </ul>
                                <ul class="product-action">
                                    <li>
                                        <a href="<?php echo e(url('DetailProduct/' . $item->id)); ?>"><?php echo e($item->name); ?></a>

                                            <i class="fa-solid fa-cart-shopping"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(url('DetailProduct/' . $item->id)); ?>"><?php echo e($item->name); ?></a>
                                        <i class="fa-solid fa-magnifying-glass-plus"></i>
                                    </a>
                                    </li>
                                    <li>
                                        <a class="addtowishlist" data-id="<?php echo e($item->id); ?>" href="javascript:void(0);">
                                        <i class="fa-solid fa-heart"></i>
                                    </a>
                                    </li>
                                </ul>

                                <a href="<?php echo e(url('DetailProduct/' . $item->id)); ?>">
                                    <img src="<?php echo e(asset('storage/images/' . $item->image)); ?>" alt="Yellow (VF1100C V65)"/>
                                </a>
                            </div>
                            <h4 class="item-title">
                                <a href="<?php echo e(url('DetailProduct/' . $item->id)); ?>"><?php echo e($item->name); ?></a>
                            </h4>
                            <div class="brand-card">
                                <div class="brand">
                                    <span>Brand <a href="#"><?php echo e($item->brand); ?></a></span>
                                </div>
                                <div class="brand">
                                    <span>Category <a href="#"><?php echo e($item->category); ?></a></span>
                                </div>
                            </div>
                            <div class="item-price-card">
                                <div class="item-price">$<?php echo e($item->price); ?></div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</div>
	<!-- /New Arrivals Section/ -->

	<!-- Trending Products Section -->
	<div class="section">
		<div class="container">
			<div class="row">
				<div class="section-heading">
					<h3 class="title">Trending Products</h3>

				</div>
			</div>
			<div class="row owl-carousel caro-common category-carousel">
                <?php $__currentLoopData = $productTrading; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-12">
                        <div class="item-card mb30">
                            <div class="item-image">
                                <ul class="product-action">
                                    <li><a href="<?php echo e(url('DetailProduct/' . $item->id)); ?>"><i class="fa-solid fa-cart-shopping"></i></a></li>
                                    <li><a href="<?php echo e(url('DetailProduct/' . $item->id)); ?>"><i class="fa-solid fa-magnifying-glass-plus"></i></a></li>
                                    <li><a class="addtowishlist" data-id="<?php echo e($item->id); ?>" href="javascript:void(0);"><i class="fa-solid fa-heart"></i></a></li>
                                </ul>
                                <a href="<?php echo e(url('DetailProduct/' . $item->id)); ?>">
                                    <img src="<?php echo e(asset('storage/images/' . $item->image)); ?>" alt="<?php echo e($item->name); ?>"/></a>
                            </div>
                            <h4 class="item-title">
                                <a href="<?php echo e(url('DetailProduct/' . $item->id)); ?>"><?php echo e($item->name); ?></a></h4>
                            <div class="brand-card">
                                <div class="brand">
                                    <span>Brand <a href="#"><?php echo e($item->brand); ?></a></span>
                                </div>
                                <div class="brand">
                                    <span>Category <a href="#"><?php echo e($item->category); ?></a></span>
                                </div>
                            </div>
                            <div class="item-price-card">
                                <div class="item-price">$<?php echo e($item->price); ?></div>
                            </div>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</div>
	<!-- /Trending Products Section/ -->

	<!-- Best Sellers Section -->
	<div class="section">
		<div class="container">
			<div class="row">
				<div class="section-heading">
					<h3 class="title">Best Sellers</h3>
					
				</div>
			</div>
			<div class="row owl-carousel caro-common category-carousel">
                <?php $__currentLoopData = $productBest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-12">
                        <div class="item-card mb30">
                            <div class="item-image">
                                <ul class="labels-list">
                                    <li><span class="tplabel" style="background:#f0983d;">HOT</span></li>
                                </ul>
                                <ul class="product-action">
                                    <li><a href="#"><i class="fa-solid fa-cart-shopping"></i></a></li>
                                    <li><a href="#"><i class="fa-solid fa-magnifying-glass-plus"></i></a></li>
                                    <li><a class="addtowishlist" data-id="<?php echo e($item->id); ?>" href="javascript:void(0);"><i class="fa-solid fa-heart"></i></a></li>
                                </ul>
                                <ul class="color-list">
                                                                <li style="background:#000000;"></li>
                                                                <li style="background:#dddddd;"></li>
                                </ul>
                                <a href="<?php echo e(url('DetailProduct/' . $item->id)); ?>"><img src="<?php echo e(asset('storage/images/' . $item->image)); ?>" alt="WiFi Drone and HD camera 777"/></a>
                            </div>
                            <h4 class="item-title"><a href="<?php echo e(url('DetailProduct/' . $item->id)); ?>"><?php echo e($item->name); ?></a></h4>
                            <div class="brand-card">
                                <div class="brand">
                                    <span>Brand <a href="#"><?php echo e($item->brand); ?></a></span>
                                </div>
                                <div class="brand">
                                    <span>Category <a href="#"><?php echo e($item->category); ?></a></span>
                                </div>
                            </div>
                            <div class="item-price-card">
                                <div class="item-price">$<?php echo e($item->price); ?></div>
                            </div>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</div>
		</div>
	</div>
	<!-- /Best Sellers Section/ -->

	<!-- Available Offer Section -->
	<div class="section">
		<div class="container">
			<div class="row">
				<div class="section-heading">
					<h3 class="title">Available Offer</h3>

				</div>
			</div>
			<div class="row owl-carousel caro-common category-carousel">
                <?php $__currentLoopData = $ProductAvailable_Offer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-12">
                        <div class="item-card mb30">
                            <div class="item-image">
                                <ul class="labels-list">
                                    <li><span class="tplabel" style="background:#f62459;">OFF</span></li>
                                </ul>
                                                            <ul class="product-action">
                                                                    <li><a href="<?php echo e(url('DetailProduct/' . $item->id)); ?>"><i class="fa-solid fa-cart-shopping"></i></a></li>
                                                                    <li><a href="<?php echo e(url('DetailProduct/' . $item->id)); ?>"><i class="fa-solid fa-magnifying-glass-plus"></i></a></li>
                                    <li><a class="addtowishlist" data-id="<?php echo e($item->id); ?>" href="javascript:void(0);"><i class="fa-solid fa-heart"></i></a></li>
                                </ul>
                                                            <ul class="color-list">
                                                                                            <li style="background:#000000;"></li>
                                                            </ul>
                                                            <a href="<?php echo e(url('DetailProduct/' . $item->id)); ?>"><img src="<?php echo e(asset('storage/images/' . $item->image)); ?>" alt="Touch LED Sports Watch"/></a>
                            </div>
                            <h4 class="item-title"><a href="<?php echo e(url('DetailProduct/' . $item->id)); ?>"><?php echo e($item->name); ?></a></h4>
                            <div class="brand-card">
                                <div class="brand">
                                    <span>Brand <a href="#"><?php echo e($item->brand); ?></a></span>
                                </div>
                                <div class="brand">
                                    <span>Category <a href="#"><?php echo e($item->category); ?></a></span>
                                </div>
                            </div>
                            <div class="item-price-card">
                                <div class="item-price">$<?php echo e($item->name); ?></div>

                            </div>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





			</div>
		</div>
	</div>
	<!-- /Available Offer Section/ -->


		<!-- /Add Part/ -->





	<!-- /Shopping Cart -->
	<div class="cart-sidebar">
		<a href="javascript:void(0);" class="sidebar-close sidebar_show_hide">
			<i class="bi bi-x-lg"></i>
		</a>
		<div class="cart-head">
		Shopping Cart
		</div>
		<div class="cart-body" id="tp_cart_data"></div>
		<div class="cart-footer">
			<div class="carttotals">
				<span class="title">Subtotal:</span>
				<span class="price sub_total"></span>
			</div>
			<div class="carttotals">
				<span class="title">Tax:</span>
				<span class="price tax"></span>
			</div>
			<div class="carttotals">
				<span class="title">Total:</span>
				<span class="price tp_total"></span>
			</div>
			<a href="#" class="btn black-btn checkout mt10">View Cart</a>
			<a href="<?php echo e(url('checkout')); ?>" class="btn theme-btn checkout">Checkout</a>
		</div>
	</div>
	<!-- /Shopping Cart -->



	<!-- js -->
	<script src="https://bshopen.themeposh.net/public/frontend/js/jquery-3.6.0.min.js"></script>
	<script src="https://bshopen.themeposh.net/public/frontend/js/popper.min.js"></script>
	<script src="https://bshopen.themeposh.net/public/frontend/js/bootstrap.min.js"></script>
	<script src="https://bshopen.themeposh.net/public/frontend/js/scrolltop.js"></script>
	<script src="https://bshopen.themeposh.net/public/frontend/js/jquery.nicescroll.min.js"></script>
	<script src="https://bshopen.themeposh.net/public/frontend/js/owl.carousel.min.js"></script>
	<script src="https://bshopen.themeposh.net/public/frontend/js/jquery.popupoverlay.min.js"></script>
	<script src="https://bshopen.themeposh.net/public/frontend/js/jquery.gritter.min.js"></script>
	<script>
		var is_rtl = "0";
		if(is_rtl == 1){
			var isRTL = true;
		}else{
			var isRTL = false;
		}
		var theme_color = "#c62f2f";
		var base_url = "https://bshopen.themeposh.net";
		var public_path = "https://bshopen.themeposh.net/public";
	</script>
	<script src="https://bshopen.themeposh.net/public/frontend/js/scripts.js"></script>
	<script src="https://bshopen.themeposh.net/public/frontend/pages/cart.js"></script>
		<div class="custom-popup light width-100 dnone" id="lightCustomModal">
		<div class="padding-md">
			<h4 class="m-top-none"></h4>
		</div>
		<div class="text-center">
			<a href="javascript:void(0);" class="btn blue-btn lightCustomModal_close mr-10" onClick="onConfirm()">Confirm</a>
			<a href="javascript:void(0);" class="btn danger-btn lightCustomModal_close">Cancel</a>
		</div>
	</div>
	<a href="#lightCustomModal" class="btn btn-warning btn-small lightCustomModal_open dnone">Edit</a>
    <script>
        function getFavorite()
    {
        $.ajax({
            type: "get",
            url: "<?php echo e(url('getFavorite')); ?>",

            dataType: "json",
            success: function (response)
            {
                if(response.status == 200)
                {
                    $('.count_wishlist').text(response.count);
                }
            }
        });
    }
    getFavorite();
         $('.addtowishlist').on('click',function()
            {

                $.ajax({
                    type: "get",
                    url: "<?php echo e(url('storeFavortie')); ?>",
                    data:
                    {
                        idproduct : $(this).attr('data-id'),
                    },
                    dataType: "json",
                    success: function (response) {
                        if(response.status == 200)
                        {
                            getFavorite();
                        }
                    }
                });
            });
    </script>
		<script type="text/javascript">

	(function ($) {
		'use strict';
		var subscribePopupModal = new bootstrap.Modal(document.getElementById('subscribe_popup'), {
		  keyboard: false
		});

		subscribePopupModal.show();

		//Subscribe for page
		$(document).on("click", ".newsletter_btn", function(event) {
			event.preventDefault();

			var newsletterEmail = $("#newsletter_email").val();
			var status = 'subscribed';

			var nletter_btn = $('.nletter_btn').html();
			var newsletter_recordid = '';

			var newsletter_email = newsletterEmail.trim();

			if(newsletter_email == ''){
				$('.newsletter_msg').html('<p class="text-danger">The email address field is required.</p>');
				return;
			}

			$.ajax({
				type : 'POST',
				url: base_url + '/frontend/saveSubscriber',
				data: 'RecordId=' + newsletter_recordid+'&email_address='+newsletter_email+'&status='+status,
				beforeSend: function() {
					$('.newsletter_msg').html('');
					$('.nletter_btn').html('<span class="spinner-border spinner-border-sm"></span> Please Wait...');
				},
				success: function (response) {
					var msgType = response.msgType;
					var msg = response.msg;

					if (msgType == "success") {
						popup_modal_close();
						subscribePopupModal.hide();
						onSuccessMsg(msg);
					} else {
						$('.newsletter_msg').html('<p class="text-danger">'+msg+'</p>');
					}

					$('.nletter_btn').html(nletter_btn);
				}
			});
		});
	}(jQuery));

	function popup_modal_close() {
		$.ajax({
			type : 'POST',
			url: base_url + '/frontend/subscribePopupOff',
			data: 'PopupOff=OFF',
			success: function (response){}
		});
	}




	</script>

	</body>
</html>
<?php /**PATH C:\xampp\htdocs\EcommerceDemo\resources\views/welcome.blade.php ENDPATH**/ ?>